package datatypes;

public enum MyAction {
	TAKE, SKIP
}
